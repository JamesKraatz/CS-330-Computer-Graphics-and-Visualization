// STL
#include <vector>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>

// Project
#include "Sphere.h"
#include <iostream>



namespace static_meshes_3D {

	Sphere::Sphere(int numWedges, int numSegments, float radius, float top, float bottom,
					   bool withPositions, bool withTextureCoordinates, bool withNormals)
		: StaticMesh3D(withPositions, withTextureCoordinates, withNormals)
		, _radius(radius)
		, _numWedges(numWedges)
		, _numSegments(numSegments)
		, _top(top)
		, _bottom(bottom)
		, _numVertexPoles(0)
	{
		initializeData();
	}

	float Sphere::getRadius() const
	{
		return _radius;
	}

	int Sphere::getWedges() const
	{
		return _numWedges;
	}

	int Sphere::getSegments() const
	{
		return _numSegments;
	}

	float Sphere::getTop() const
	{
		return _top;
	}

	float Sphere::getBottom() const
	{
		return _bottom;
	}

	void Sphere::initializeData()
	{
		if (_isInitialized) {
			return;
		}

		// limit top and bottom
		if (_top >= (_radius - 0.001f)) _top = _radius - 0.001f;
		if (_bottom <= (-_radius + 0.001f)) _bottom = -_radius + 0.001f;

		// Validate numSegments
		if (_numSegments == INT_MAX) _numSegments = _numWedges;

		// Calculate and cache numbers of vertices
		_numVerticesSide = (_numWedges + 1) * (_numSegments + 1);
		_numVerticesTopBottom = (_numWedges + 2);
		_numVerticesTotal = _numVerticesSide + (_numVerticesTopBottom * 2);
		int numTriangles = 2 * _numWedges * (_numSegments + 1);
		_numVerticesTotal = numTriangles * 3;

		// Generate VAO and VBO for vertex attributes
		glGenVertexArrays(1, &_vao);
		glBindVertexArray(_vao);
		_vbo.createVBO(getVertexByteSize() * _numVerticesTotal);

		std::vector<glm::vec3> positions;
		std::vector<glm::vec3> normals;
		std::vector<glm::vec2> texCoords;

		float zx;							// cache cos of angle in zx plane
		float lengthInv = 1.0f / _radius;	// inverse of radius
		glm::vec3 position;					// vertex position
		glm::vec3 normal;					// vertex normal
		glm::vec2 texCoord;					// vertex texture coordinate

		constexpr float CIRCLE = 2 * glm::pi<float>();
		constexpr float HALF_CIRCLE = glm::pi<float>();
		float SEGMENT_START_ANGLE = (float)asin(_top / _radius);
		float SEGMENT_STOP_ANGLE = (float)asin(_bottom / _radius);
		const float SEGMENT_ANGLE_SPAN = SEGMENT_START_ANGLE + SEGMENT_STOP_ANGLE;
		const auto wedgeAngleStep = CIRCLE / float(_numWedges);
		const auto segmentAngleStep = SEGMENT_ANGLE_SPAN / (_numSegments);
		const auto wedgeAngleStart = wedgeAngleStep / 2.0f;

		float wedgeAngle, segmentAngle;

		// top-polar vertices "may be a circular plane"
		// do top center point repeated numWedges + 1
		for(auto i = 0; i <= _numWedges; i++)
		{
			positions.push_back(glm::vec3(0.0f, _top, 0.0f));
			normals.push_back(glm::vec3(0.0f, 1.0f, 0.0f));
			texCoords.push_back(glm::vec2(1.0f, 1.0f));
		}

		// non-polar vertices
		for (int i = 0; i <= _numSegments; i++)
		{
			segmentAngle = SEGMENT_START_ANGLE - i * segmentAngleStep;	// starting from pi/2 to -pi/2
			zx = _radius * cos(segmentAngle);							// r * cos(u)
			position.y = _radius * sin(segmentAngle);					// r * sin(u)

			// add (numWedges + 1) vertices per segment
			// the first and last vertices have same position and normal, but different texture coords
			for (int j = 0; j <= _numWedges; j++)
			{
				wedgeAngle = (j * wedgeAngleStep);				// starting at -1/2 step angle

				//vertex position (x, y, z)
				position.z = zx * cos(wedgeAngle);				// r * cos(u) * cos(v)
				position.x = zx * sin(wedgeAngle);				// r * cos(u) * sin(v)
				positions.push_back(position);

				// normalized vertex normal (nx, ny, nz)
				normal = position * lengthInv;
				normals.push_back(normal);

				// vertex tex coord (s, t) range between [0, 1]
				texCoord.s = (float)j / _numWedges;
				texCoord.t = (float)i / _numSegments;
				texCoords.push_back(texCoord);
			}
		}

		// bottom-polar vertices "may be a circular plane"
		for (auto i = 0; i <= _numWedges; i++)
		{
			positions.push_back(glm::vec3(0.0f, _bottom, 0.0f));
			normals.push_back(glm::vec3(0.0f, -1.0f, 0.0f));
			texCoords.push_back(glm::vec2(1.0f, 1.0f));
		}

		// generate CCW index list of shere triangles
		// k1--k1+1
		// |    |
		// |    |
		// k2 == k2 + 1
		std::vector<int> indices;
		std::vector<int> lineIndices;
		int k1, k2;
		for (auto i = 0; i < _numSegments + 2; ++i)
		{
			k1 = i * (_numWedges + 1);	// beginning of the current segment
			k2 = k1 + _numWedges + 1;	// beginning of the nex segment

			for (auto j = 0; j < _numWedges; j++, k1++, k2++)
			{
				// 2 trinagles per sector excluding first and last segment
				// k1 => k2 => k1 + 1
				if (i != 0)						// don't include in first segment
				{
					indices.push_back(k1);
					indices.push_back(k2);
					indices.push_back(k1 + 1);
				}

				// k1 + 1 => k2 => k2 + 1
				if (i != (_numSegments + 1))	// don't include in last segment
				{
					indices.push_back(k1 + 1);
					indices.push_back(k2);
					indices.push_back(k2 + 1);
				}

				// store indices for lines
				// vertical lines for all segments, k1 => k2
				lineIndices.push_back(k1);
				lineIndices.push_back(k2);
				if (i != 0)		// horizontal lines except 1st stack, k1 => k + 1
				{
					lineIndices.push_back(k1);
					lineIndices.push_back(k1 + 1);
				}
			}
		}

		// update number of vertices to indexed vertices size
		if (indices.size() != _numVerticesTotal)
			std::cout << "indices size mismatch" << std::endl;

		if (hasPositions())
		{

			//glm::vec3 *data = positions.data();
			//int sizeOfData = sizeof(glm::vec3) * indices.size();
			//_vbo.addRawData(data, sizeOfData);
			std::vector <glm::vec3> newData;
				for (auto i : indices)
				{
					newData.push_back(positions[i]);
					//	auto index = indices[i];
					//	const auto& position = positions[index];
					//	_vbo.addRawData(&position, sizeof(glm::vec3));
					//}
				}
			_vbo.addRawData(newData.data(), sizeof(glm::vec3) * newData.size());
		}

		if (hasTextureCoordinates())
		{
			//glm::vec2* data = texCoords.data();
			//int sizeOfData = sizeof(glm::vec2) * indices.size();
			//_vbo.addRawData(data, sizeOfData);
			std::vector <glm::vec2> newData;
			for (auto i : indices)
			{
				newData.push_back(texCoords[i]);
			//	auto index = indices[i];
			//	const auto& texCoord = texCoords[index];
			//	_vbo.addRawData(&texCoord, sizeof(glm::vec2));
			//}
			}
			_vbo.addRawData(newData.data(), sizeof(glm::vec3)* newData.size());
		}

		if (hasNormals())
		{
			//glm::vec3* data = normals.data();
			//int sizeOfData = sizeof(glm::vec3) * indices.size();
			//_vbo.addRawData(data, sizeOfData);
			std::vector <glm::vec3> newData;
			for (auto i : indices)
			{
				newData.push_back(normals[i]);
			//	auto index = indices[i];
			//	const auto& normal = normals[index];
			//	_vbo.addRawData(&normal, sizeof(glm::vec3));
			//}
			}
		_vbo.addRawData(newData.data(), sizeof(glm::vec3)* newData.size());
		}

		// Finally upload data to the GPU
		_vbo.bindVBO();
		_vbo.uploadDataToGPU(GL_STATIC_DRAW);
		setVertexAttributesPointers(indices.size());

		_isInitialized = true;
		positions.clear();
		texCoords.clear();
		normals.clear();
		indices.clear();
	}

	void Sphere::render() const
	{
		if (!_isInitialized) {
			return;
		}

		glBindVertexArray(_vao);

		// Render sphere
		glDrawArrays(GL_TRIANGLES, 0, _numVerticesTotal);
	}

	void Sphere::renderPoints() const
	{
		if (!_isInitialized) {
			return;
		}

		// Just render all points as they are stored in the VBO
		glBindVertexArray(_vao);
		glDrawArrays(GL_POINTS, 0, _numVerticesTotal);
	}

} // namespace static_meshes_3D