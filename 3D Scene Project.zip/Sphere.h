#pragma once
#include "common/staticMesh3D.h"

namespace static_meshes_3D {

	/**
	* Sphere static mesh with given radius, number of slices and height.
	*/
	class Sphere : public StaticMesh3D
	{
	public:
		Sphere(int numWedges, int numSegments = INT_MAX, float radius = 1.0f, float top = FLT_MAX, float bottom = -FLT_MAX,
			bool withPositions = true, bool withTextureCoordinates = true, bool withNormals = true);

		void render() const override;
		void renderPoints() const override;

		/**
		 * Gets Sphere radius.
		 */
		float getRadius() const;

		/**
		 * Gets number of sphere wedges.
		 */
		int getWedges() const;

		/**
		 * Gets number of sphere segments.
		 */
		int getSegments() const;

		/**
		 * Gets sphere top.
		 */
		float getTop() const;

		/**
		* Gets sphere bottom.
		*/
		float getBottom() const;

	private:
		float _radius;		// Sphere radius (distance from the center of cylinder to surface)
		int _numWedges;		// Number of sphere wedges
		int _numSegments;	// Number of sphere segments
		float _top;			// Top of the sphere
		float _bottom;		// Bottom of the sphere

		int _numVerticesSide;		// How many vertices to render side of the sphere
		int _numVerticesTopBottom;	// How many vertices to render top / bottom of the sphere
		int _numVerticesTotal;		// Just a sum of both numbers above
		int _numVertexPoles;		// Number of poles drawn "min 0 max 2"
		bool _addTopPole;			// Add vertices for the top pole?
		bool _addBottomPole;		// Add vertices for the bottom pole?

		void initializeData() override;
	};

} // namespace static_meshes_3D