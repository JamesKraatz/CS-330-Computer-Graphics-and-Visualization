#include "ShapeGenerator.h"
#include "ShapeData.h"
#include "CubeGenerator.h"
#include "cylinderGenerator.h"
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <string>

#include "shader.h"
#include "camera.h"
#include "cube.h"
#include "cylinder.h"


#include <iostream>



void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);
void createCylinderVerts(std::vector<float>* vertices, int nSlices, float height, float red, float green, float blue);
void createCubeVerts(std::vector<float>* vertices, float lengthX, float lengthY, float lengthZ, float red, float green, float blue);
GLuint loadObject(unsigned int* VAO, unsigned int* VBO, ShapeData *object);// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 6.0f));
//Camera camera(glm::vec3(1.5f, 3.0f, 6.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;

bool perspective = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

// offset variables for plane, sphere
const uint NUM_VERTICES_PER_TRI = 3;
const uint NUM_FLOATS_PER_VERTICE = 9;
const uint VERTEX_BYTE_SIZE = NUM_FLOATS_PER_VERTICE * sizeof(float);

// plane
GLuint planeNumIndices;
GLuint planeVertexArrayObjectID;
GLuint planeIndexByteOffset;

// sphere
GLuint sphereNumIndices;
GLuint sphereVertexArrayObjectID;
GLuint sphereIndexByteOffset;

GLuint sphereNumIndices2;
GLuint sphereVertexArrayObjectID2;
GLuint sphereIndexByteOffset2;

// projection matrix
glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);

int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "James Kraatz: Module 5 Milestone", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------

	Shader objectShader("shaderfiles/mod6MlStn.vs", "shaderfiles/mod6MlStn.fs");
	Shader lightShader("shaderfiles/6.light_cube.vs", "shaderfiles/6.light_cube.fs");

	Shader clockFaceShader("shaderfiles/7.3.camera.vs", "shaderfiles/7.3.camera.fs");

	// positions of the point lights
	glm::vec3 pointLightPositions[] = {
		glm::vec3( 0.8f,  2.8f,  -1.2f),
		glm::vec3( 2.0f,  0.5f,   1.0f),
		glm::vec3(-4.0f,  2.0f, -12.0f),
		glm::vec3( 0.0f,  0.0f,  -3.0f)
	};

	// cup handle cube's VAO and VBO
	unsigned int cubeVBO, cubeVAO;

	glGenVertexArrays(1, &cubeVAO);
	glGenBuffers(1, &cubeVBO);

	glBindVertexArray(cubeVAO);
	// position attribute for cube
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// texture attribute for cube
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	// normal attribute for cube
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(5 * sizeof(float)));
	glEnableVertexAttribArray(2);


	// position attribute for cube
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// texture attribute for cube
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	// normal attribute for cube
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(5 * sizeof(float)));
	glEnableVertexAttribArray(2);

	// lightCube's VAO and VBO
	unsigned int lightCubeVAO;
	glGenVertexArrays(1, &lightCubeVAO);
	glBindVertexArray(lightCubeVAO);

	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
	// note that we update the lamp's position attribute's stride to reflect the updated buffer data
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);


	// create plane from ShapeGenerator
	// --------------------------------
	ShapeData myPlane = ShapeGenerator::makePlane(2);
	unsigned int myPlaneVBO{}, myPlaneVAO;
	GLuint myPlaneIndexByteOffset = loadObject(&myPlaneVAO, &myPlaneVBO, &myPlane);

	ShapeData myCube = CubeGenerator::makeCube();
	unsigned int myCubeVBO{}, myCubeVAO;
	GLuint myCubeIndexByteOffset = loadObject(&myCubeVAO, &myCubeVBO, &myCube);

	ShapeData myCylinder = CylinderGenerator::makeCylinder(100, 0.5f);
	unsigned int myCylinderVBO{}, myCylinderVAO;
	GLuint myCylinderIndexByteOffset = loadObject(&myCylinderVAO, &myCylinderVBO, &myCylinder);

	// load textures using utility function
	unsigned int planeDiffuseMap = loadTexture("images/marble.jpg");
	unsigned int eggDiffuseMap = loadTexture("images/egg.jpg");
	unsigned int greenBoxDiffuseMap = loadTexture("images/green.jpg");
	unsigned int magentaBoxDiffuseMap = loadTexture("images/magenta.jpg");
	unsigned int brassTexture = loadTexture("images/gold_textured_background_hd_picture_3_169654.jpg");
	unsigned int silverTexture = loadTexture("images/metal_texture_set_03_hd_picture_170837.jpg");
	unsigned int awesomeFace = loadTexture("images/awesomeface.png");
	unsigned int clockDial = loadTexture("images/pngkit_clock-vector-png_1190415.png");

	static_meshes_3D::Cube book(0.25f, 3.0f, 4.0f, true, true, true);
	static_meshes_3D::Cube clockBody(1.0f, 1, 1.0f, true, true, true);
	static_meshes_3D::Sphere clockFace(0.5f, 30, 1.0f, true, true, true);


	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	// -------------------------------------------------------------------------------------------
	objectShader.Activate();
	objectShader.setInt("material.diffuse", 0);
	objectShader.setInt("material.specular", 1);

	clockFaceShader.Activate();
	clockFaceShader.setInt("texture1", 0);
	clockFaceShader.setInt("texture2", 1);

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		objectShader.Activate();
		objectShader.setInt("material.diffuse", 0);
		objectShader.setInt("material.specular", 1);

		//objectShader.Activate();
		objectShader.setVec3("viewPos", camera.Position);
		objectShader.setFloat("material.shininess", 32.0f);

		// directional light
		objectShader.setVec3("dirLight.direction", 2.5f, 0.0f, 0.0f);
		objectShader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
		objectShader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
		objectShader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
		// key light
		objectShader.setVec3("pointLights[0].position", pointLightPositions[0]);
		objectShader.setVec3("pointLights[0].ambient", 0.5f, 0.5f, 0.5f);
		objectShader.setVec3("pointLights[0].diffuse", 0.5f, 0.5f, 0.5f);
		objectShader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
		objectShader.setFloat("pointLights[0].constant", 1.0f);
		objectShader.setFloat("pointLights[0].linear", 0.09);
		objectShader.setFloat("pointLights[0].quadratic", 0.032);
		// fill light
		objectShader.setVec3("pointLights[1].position", pointLightPositions[1]);
		objectShader.setVec3("pointLights[1].ambient", 0.7f, 0.7f, 0.7f);
		objectShader.setVec3("pointLights[1].diffuse", 0.1f, 0.1f, 0.1f);
		objectShader.setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
		objectShader.setFloat("pointLights[1].constant", 1.0f);
		objectShader.setFloat("pointLights[1].linear", 0.09);
		objectShader.setFloat("pointLights[1].quadratic", 0.032);
		// point light 3
		objectShader.setVec3("pointLights[2].position", pointLightPositions[2]);
		objectShader.setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
		objectShader.setVec3("pointLights[2].diffuse", 0.8f, 0.8f, 0.8f);
		objectShader.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
		objectShader.setFloat("pointLights[2].constant", 1.0f);
		objectShader.setFloat("pointLights[2].linear", 0.09);
		objectShader.setFloat("pointLights[2].quadratic", 0.032);
		// point light 4
		objectShader.setVec3("pointLights[3].position", pointLightPositions[3]);
		objectShader.setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
		objectShader.setVec3("pointLights[3].diffuse", 0.8f, 0.8f, 0.8f);
		objectShader.setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
		objectShader.setFloat("pointLights[3].constant", 1.0f);
		objectShader.setFloat("pointLights[3].linear", 0.09);
		objectShader.setFloat("pointLights[3].quadratic", 0.032);
		// spotLight
		objectShader.setVec3("spotLight.position", camera.Position);
		objectShader.setVec3("spotLight.direction", camera.Front);
		objectShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
		objectShader.setVec3("spotLight.diffuse", 0.7f, 0.7f, 0.7f);
		objectShader.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
		objectShader.setFloat("spotLight.constant", 1.0f);
		objectShader.setFloat("spotLight.linear", 0.09);
		objectShader.setFloat("spotLight.quadratic", 0.032);
		objectShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
		objectShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

		// view/projection transformations
		glm::mat4 view = camera.GetViewMatrix();
		objectShader.setMat4("projection", projection);
		objectShader.setMat4("view", view);

		// world transformation
		glm::mat4 model = glm::mat4(1.0f);
		objectShader.setMat4("model", model);

		// setup to draw myPlane
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, planeDiffuseMap);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, eggDiffuseMap);
		glBindVertexArray(myPlaneVAO);
		model = model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(4.0f, -0.0001f, 2.0f));
		model = glm::rotate(model, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::scale(model, glm::vec3(8.0f, 1.0f, 5.0f));
		objectShader.setMat4("model", model);

		// draw plane
		glDrawElements(GL_TRIANGLES, myPlane.numIndices, GL_UNSIGNED_SHORT, (void*)myPlaneIndexByteOffset);

		// setup to draw myCube
		glBindTexture(GL_TEXTURE_2D, greenBoxDiffuseMap);
		glBindVertexArray(myCubeVAO);
		model = model = glm::mat4(1.0f);
		// move cube
		model = glm::translate(model, glm::vec3(3.15f, 0.25f, 0.0f));
		// rotate cube
		model = glm::rotate(model, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		// scale cube
		model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.3f)); // Make it a smaller cube
		objectShader.setMat4("model", model);

		// draw myCube
		//glDrawElements(GL_TRIANGLES, myCube.numIndices, GL_UNSIGNED_SHORT, (void*)myCubeIndexByteOffset);

		// setup to draw myCylinder
		glBindTexture(GL_TEXTURE_2D, magentaBoxDiffuseMap);
		glBindVertexArray(myCylinderVAO);
		model = model = glm::mat4(1.0f);
		// move cylinder right, up, and forward toward viewer
		model = glm::translate(model, glm::vec3(3.0f, 0.25f, 0.35f));
		// rotate cylinder about y axis
		model = glm::rotate(model, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		// scale cylinder
		model = glm::scale(model, glm::vec3(5.0f, 5.0f, 5.0f));
		//model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.3f));
		objectShader.setMat4("model", model);

		// draw myCylinder
		//glDrawElements(GL_TRIANGLES, myCylinder.numIndices, GL_UNSIGNED_SHORT, (void*)myCylinderIndexByteOffset);

		// draw book
		// setup to draw book
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, magentaBoxDiffuseMap);
		model = model = glm::mat4(1.0f);
		// move book right, up, and forward toward viewer
		model = glm::translate(model, glm::vec3(0.0f, book.getHeight() /2.0f, 0.0f));
		// rotate book about y axis
		//model = glm::rotate(model, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::rotate(model, glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		// scale book
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		//model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.3f));
		objectShader.setMat4("model", model);

		// draw myCylinder
		book.render();

		// draw clock body
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, silverTexture);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, silverTexture);
		model = model = glm::mat4(1.0f);
		// move clock body right, up, and forward toward viewer
		model = glm::translate(model, glm::vec3(3.0f, clockBody.getHeight() / 2.0f, 0.3f));
		// rotate clock body about y axis
		model = glm::rotate(model, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		// scale clock body
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		//model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.3f));
		objectShader.setMat4("model", model);
		clockBody.render();

		glBindVertexArray(0);


		// draw clock face
		clockFaceShader.Acitvate();
		clockFaceShader.setMat4("view", view);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, brassTexture);
		//clockFaceShader.setInt("texture1", 0);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, clockDial);
		//clockFaceShader.setInt("texture2", 1);
		
		clockFaceShader.setMat4("projection", projection);
		clockFaceShader.setMat4("view", view);
		model = glm::mat4(1.0f);
		// move clock face right, up, and forward toward viewer
		model = glm::translate(model, glm::vec3(2.925f, clockBody.getHeight() / 2.0f, 0.45f));
		// rotate clock face about y axis
		model = glm::rotate(model, glm::radians(-25.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		// scale clock face
		// rotate clock about x-axis 
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::scale(model, glm::vec3(0.8f, 0.8f, 0.8f));
		//model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.3f));
		clockFaceShader.setMat4("model", model);
		clockFace.render();

		
	

		glActiveTexture(GL_TEXTURE1);
		glDisable(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE0);
		glDisable(GL_TEXTURE_2D);
		glBindVertexArray(0);

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	glDeleteVertexArrays(1, &myCubeVAO);
	glDeleteBuffers(1, &myCubeVBO);

	glDeleteVertexArrays(1, &myCylinderVAO);
	glDeleteBuffers(1, &myCylinderVBO);

	glDeleteVertexArrays(1, &myPlaneVAO);
	glDeleteBuffers(1, &myPlaneVBO);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);


	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(UP, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(DOWN, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);

	// change view between perspective and orthographics
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
		const float width = (float)SCR_WIDTH / 2.0f;
		const float height = (float)SCR_HEIGHT / 2.0f;
		const float aspectRatio = width / height;

		if (perspective) {
			projection = glm::ortho(-5.0f * aspectRatio, 5.0f * aspectRatio, -5.0f, 5.0f , 0.1f, 100.0f);
			perspective = false;
		}
		else {
			projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
			perspective = true;
		}
	}

}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll(yoffset);
}

unsigned int loadTexture(char const* path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}

//void loadObject(unsigned int* VAO, unsigned int* VBO, std::vector<float>* shapeData, std::vector<int>* dataStepSize)
GLuint loadObject(unsigned int* VAO, unsigned int* VBO, ShapeData * object)
{
	const int nDataGroups = 3;
	const int nFloats = 3;

	GLsizeiptr currentOffset = 0;
	GLuint indexByteOffset;
	GLuint objectNumIndices;

	glGenVertexArrays(1, VAO);
	glGenBuffers(1, VBO);
	glBindVertexArray(*VAO);
	glBindBuffer(GL_ARRAY_BUFFER, *VBO);
	glBufferData(GL_ARRAY_BUFFER, object->vertexBufferSize() + object->indexBufferSize(), 0, GL_STATIC_DRAW);
	currentOffset = 0;
	glBufferSubData(GL_ARRAY_BUFFER, currentOffset, object->vertexBufferSize(), object->vertices);
	currentOffset += object->vertexBufferSize();
	indexByteOffset = currentOffset;
	glBufferSubData(GL_ARRAY_BUFFER, currentOffset, object->indexBufferSize(), object->indices);
	objectNumIndices = object->numIndices;


	for (int i = 0; i < nDataGroups; i++)
	{
		glEnableVertexAttribArray(i);
		glVertexAttribPointer(i, nFloats, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)(sizeof(float) * (i * nFloats)));
	}
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, *VBO);

	return indexByteOffset;
}
