#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"

#include <iostream>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);

bool initializeWindow(GLFWwindow** window);

// settings
const unsigned int WINDOW_WIDTH = 800;
const unsigned int WINDOW_HEIGHT = 600;
const char* WINDOW_TITLE = "James Kraatz: CS330 Module 3 Milestone";

const char* vertexFile   = "shaderfiles/vertShader.vs";
const char* fragmentFile = "shaderfiles/fragShader.fs";

const char* containerFile   = "images/container.jpg";
const char* awesomefaceFile = "images/awesomeface.png";

//// declare window to initialize
//GLFWwindow* window = nullptr;

int main()
{
	//// initialize and configure window
	//// -------------------------------
	//if (initializeWindow(&window))
	//{
	//	return EXIT_FAILURE;
	//}

	// declare window to initialize
	GLFWwindow* window = nullptr;

	//================================================================================================
	// glfw: initialize and configure
// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return false;
	}

	// display OpenGL Version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	//========================================================================================

	// build and compile our shader program
	// ------------------------------------
	Shader ourShader(vertexFile, fragmentFile, nullptr);

	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------
	// pyramid:
	float vertices[] = {
		// position attributes	// color attributes (r, g, b, a)
		 0.0f,  1.0f,  0.0f,	1.0f, 1.0f,	1.0f, 1.0f,	// top		   white
		-1.0f, -1.0f,  1.0f,	1.0f, 0.0f,	1.0f, 1.0f,	// front left  purple
		 1.0f, -1.0f,  1.0f,	1.0f, 1.0f,	0.0f, 1.0f,	// front right yellow
		 1.0f, -1.0f, -1.0f,	0.0f, 0.0f,	1.0f, 1.0f,	// rear  right blue
		-1.0f, -1.0f, -1.0f,    0.0f, 1.0f,	1.0f, 1.0f	// rear  left  cyan
	};
	const unsigned int floatsPerVertex = 3;
	const unsigned int floatsPerColor = 4;

	unsigned int indices[]{
		0, 1, 2,	//        front triangle
		0, 2, 3,	//        right triangle
		0, 3, 4,	//        rear  triangle
		0, 1, 4,	//        left  triangle
		1, 2, 4,	// bottom left  triangle
		2, 3, 4		// bottom right triangle
	};
	const unsigned int nIndices = sizeof(indices) / sizeof(indices[0]);

	unsigned int VBOs[2];
	unsigned int VAO;
	glGenVertexArrays(1, &VAO);
	
	// bind VAO object
	glBindVertexArray(VAO);
	
	glGenBuffers(2, VBOs);

	// select vertices VBO of selected VAO
	glBindBuffer(GL_ARRAY_BUFFER, VBOs[0]);
	// move vertices data to VBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// select indices VBO 
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VBOs[1]);
	// move indices data to vBO
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	// strides between vertex coordinates is 7 (x, y, z, r, g, b, a)
	// the spacing of floats for each vetex and color combined
	unsigned int stride = sizeof(float) * (floatsPerVertex + floatsPerColor);
	// position attribute
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, (void*)0);
	glEnableVertexAttribArray(0);
	// color attribute
	glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	// note that this is allowed, the call to glVertexAttribPointer registerd VBO as the vertex attribute's bound
	// vertex buffer object so afterwards we can safely unbind
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// input
		// -----
		processInput(window);

		// configure global OpenGL state
		// -----------------------------
		// enable depth text
		glEnable(GL_DEPTH_TEST);
		// accept fragment if it is closer to the camera than the former one
		glDepthFunc(GL_LESS);

		// render
		// ------
		//glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// create transformations
		// 1. scale the shape
		glm::mat4 scale = glm::mat4(1.0f);
		scale = glm::scale(glm::vec3(0.5f, 0.5f, 0.5f));
		// 2. rotate the shape
		glm::mat4 rotationWireframe = glm::mat4(1.0f);
		rotationWireframe = glm::rotate(glm::radians(-45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 rotationSolid = glm::mat4(1.0);
		rotationSolid = glm::rotate(glm::radians(10.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		// 3. translate the shape
		glm::mat4 translationWireframe = glm::mat4(1.0f);
		translationWireframe = glm::translate(glm::vec3(-1.0f, 0.0f, 0.0f));
		glm::mat4 translationSolid = glm::mat4(1.0f);
		translationSolid = glm::translate(glm::vec3(1.0f, 0.0f, 0.0f));
		// 4. model matrix: transformations are applied right-to-left order
		glm::mat4 modelWireframe = translationWireframe * rotationWireframe * scale;
		glm::mat4 modelSolid = translationSolid * rotationSolid * scale;

		// create view and set camera position
		// moves scene into the screen (which is the same as backing the camera up)
		glm::mat4 view = glm::mat4(1.0f);
		view = glm::translate(glm::vec3(0.0f, 0.0f, -3.0f));	 

		// create a perspectiv projection (field of view, aspect ration, near plane, and far plane are the four parameters
		glm::mat4 projection = glm::mat4(1.0f);
		projection = glm::perspective(45.0f, (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);

		// activate shader
		ourShader.use();

		// set wirefram mode
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

		// Put matrices in shader program form wirefram
		ourShader.setMat4("model", modelWireframe);
		ourShader.setMat4("view", view);
		ourShader.setMat4("projection", projection);

		// activate the VBOs in the shader's VAO
		glBindVertexArray(VAO);
		glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, NULL);
		
		glBindVertexArray(0);

		// set solid fill mode
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

		// Put matrices in shader program form wirefram
		ourShader.setMat4("model", modelSolid);
		ourShader.setMat4("view", view);
		ourShader.setMat4("projection", projection);

		// activate the VBOs in the shader's VAO
		glBindVertexArray(VAO);
		glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, NULL);

		glBindVertexArray(0);

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// de-allocate all resources
	// -------------------------
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, VBOs);
	
	// glfw: terminate, clearing al previously allocated GLFW resources
	// ----------------------------------------------------------------
	glfwTerminate();
	return 0;
}

bool initializeWindow(GLFWwindow** window)
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	*window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, framebuffer_size_callback);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return false;
	}

	// display OpenGL Version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	return true;
}

// process all input: query GLFW whether relevant keys are pressed/released this fram and react accordingly
// --------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, true);
	}
}

// glfw: whenever the window size changes (by OS or user resize) this call back function executes
// ----------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; not that width and
	// height will be significantly larger than specified on retina displays
	glViewport(0, 0, width, height);
}
