#include <vector>

std::vector<float> vertices;
std::vector<float> normals;
std::vector<float> texCoords;

float x, y, z, zx;								// vertex position
float nx, ny, nz, lengthInv = 1.0f / _radius;	// vertex normal
float s, t;										// vertex texCoord

const float CIRCLE = 2 * glm::pi<float>;
const float HALF_CIRCLE = glm::pi<float>;
const float SEGMENT_START_ANGLE = (float)asin(_top / _radius);
const float SEGMENT_STOP_ANGLE = (float)asin(_bottom / _radius);
const float SEGMENT_ANGLE_SPAN = SEGMENT_START_ANGLE - SEGMENT_STOP_ANGLE;


float wedgeAngleStep = CIRCLE / numWedges;
float segmentAngleStep = SEGMENT_ANGLE_SPAN / numSegments;
float wedgeAngle, segmentAngle;


for (int i = 0; i <= numSegments; i++)
{
	segmentAngle = SEGMENT_START_ANGLE - i * segmentAngleStep;	// starting from pi/2 to -pi/2
	zx = _radius * cos(segmentAngle);			// r * cos(u)
	y = _radius * sin(segmentAngle);				// r * sin(u)

	// add (numWedges + 1) vertices per segment
	// the first and last vertices have same position and normal, but different texture coords
	for (int j = 0; j <= numWedges; j++)
	{
		wedgeAngle = j * wedgeStep;				// starting from 0 to 2pi

		//vertex position (x, y, z)
		z = zx * cos(wedgeAngle);				// r * cos(u) * cos(v)
		x = zx * sin(wedgeAngle);				// r * cos(u) * sin(v)
		vertices.push_back(x);
		vertices.push_back(y);
		vertices.push_back(z);

		// normalized vertex normal (nx, ny, nz)
		nx = x * lenghtInv;
		ny = y * lengthInv;
		nz = z * langthInv;
		normals.push_back(nx);
		normals.push_back(ny);
		normals.push_back(nz);

		// vertex tex coord (s, t) range between [0, 1]
		s = (float)j / numSedges;
		t = (float)i / numSegments;
		texCoords.push_back(s);
		texCoords.push_back(t);
	}
}

// generate CCW index list of shere triangles
// k1--k1+1
// |    |
// |    |
?? k2==k2+1
std::vector<int> indices;
std::vector<int> lineIndices;
int k1, k2;
for (int i = 0; i < numSegments; ++i)
{
	k1 = i * (numWedges + 1);	// beginning of the current segment
	k2 = k1 + numWedges + 1;	// beginning of the nex segment

	for (int j = o; j < numWedges; j++, k1++, k2++)
	{
		// 2 trinagles per sector excluding first and last stacks
		// k1 => k2 => k1 + 1
		if (i != 0)
		{
			indices.push_bakc(k1);
			indices.push_back(k2);
			indices.push_back(k1 + 1);
		}

		// k1 + 1 => k2 => k2 + 1
		if (i != (numSegments - 1))
		{
			indices.push_back(k1 + 1);
			indices.push_back(k2);
			indices.push_back(k2 + 1);
		}

		// store indices for lines
		// vertical lines for all segments, k1 => k2
		lineIndices.push_back(k1);
		lineIndices.push_back(k2);
		if (i != 0)		// horizontal lines except 1st stack, k1 => k + 1
		{
			lineIndices.push_back(k1);
			lineIndices.push_back(k1 + 1);
		}
	}
}